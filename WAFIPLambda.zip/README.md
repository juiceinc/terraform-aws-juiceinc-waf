# IP Reputation Lambda

This code was borrowed from here: https://github.com/aws-samples/aws-waf-sample/tree/master/waf-reputation-lists/lambda
The zip is pre-built in the root of the repo and works as is, but if you would like to make modifications you can edit
it and rebuild the package with ``make package`` in the WAFIPLambda folder.  You will need to install npm dependencies
first in that directory with  ``npm install``.